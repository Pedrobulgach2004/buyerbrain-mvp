# Clase 2 · BuyerBrain
Fecha: 05/08/2026
Integrantes: Juan Martín Sastre y Pedro Bulgach

## 1. El problema

A un responsable de marketing de una tienda online pequeña de indumentaria le cuesta entender por qué potenciales clientes no compran cuando hay tráfico o carritos iniciados, pero la conversión es baja.

## 2. Usuario principal

Rol concreto: Responsable de marketing de una tienda online pequeña de indumentaria.

Quién decide y quién paga: Suponemos que el Responsable de Marketing Digital o Gerente Comercial impulsaría la contratación. En una empresa chica, el dueño o Gerente General aprobaría el pago; en una empresa mediana o grande, lo haría el área de Finanzas o CFO. Hay que validarlo.

Le vendemos a una organización o a una persona: A la empresa dueña de la tienda online.

## 3. Cómo lo resuelven hoy

1. El equipo atrae visitantes mediante campañas y observa su actividad en la tienda online.
2. Consulta métricas como tráfico, conversión y abandono del carrito.
3. Como esas métricas muestran qué ocurrió pero no necesariamente por qué, el equipo formula una explicación.
4. Toma decisiones de marketing, precio, comunicación o stock a partir de esa explicación.
5. Observa después si las ventas mejoran y, si no mejoran, revisa la hipótesis y rehace parte del trabajo.

No tenemos todavía el relato de una persona entrevistada que confirme que este sea el proceso real.

## 4. Qué les cuesta

Situación relatada por el equipo: una tienda online de indumentaria hizo una campaña fuerte en redes, obtuvo tráfico y muchos carritos abandonados. El equipo atribuyó el problema al precio y aplicó descuentos agresivos. Las ventas no crecieron significativamente y cayó el margen. Según el ejemplo, el problema real era que los talles disponibles no se mostraban con claridad. Luego tuvieron que rehacer la campaña, ajustar el stock y la comunicación, y explicar a la gerencia por qué los descuentos no funcionaron.

Este caso todavía no fue confirmado mediante una entrevista.

## 5. Lo que estamos suponiendo sin evidencia

- Que el responsable de marketing necesita conocer las causas de la no compra y no puede obtenerlas con sus herramientas actuales.
- Que es posible identificar por qué una persona no compró, y registrar esa información de manera confiable.
- Que comprender la situación individual de cada visitante aporta más valor que analizar patrones agregados.
- Que las explicaciones equivocadas sobre la baja conversión generan decisiones costosas con suficiente frecuencia.
- Que una empresa pagaría por resolver este problema.
- Que Marketing o Gerencia Comercial decidiría contratar y que el dueño, Gerencia General o Finanzas aprobaría el pago.
- Respuesta floja a confirmar en entrevistas: no contamos con un caso real detallado de un local físico; por eso cambiamos el usuario principal del gerente del local al responsable de marketing de una tienda online.

BuyerBrain no resolvería el diseño o mejora del sitio web, la gestión de inventario, la creación o ejecución de campañas, ni los cambios de precios o promociones. Se enfocaría en comprender y registrar las razones de no compra; esta definición de alcance también debe validarse.

## 6. SIPOC B2B

![SIPOC B2B de BuyerBrain](assets/buyerbrain/sipoc-b2b.png)

- **Supplier:** plataforma de e-commerce; clientes y visitantes; equipo de marketing; sistema de ventas; catálogo e inventario de la tienda.
- **Input:** historial de compras; productos visitados; carritos abandonados; respuestas voluntarias sobre motivos de abandono; catálogo, precios y stock; preferencias y consentimiento del cliente.
- **Process:** reunir y ordenar datos para detectar patrones de compra y abandono; dividir a los clientes en grupos; crear ofertas a medida; revisión de Marketing; medición de compras y recompras.
- **Output:** motivos y patrones de no compra; segmentos de clientes; ofertas recomendadas; destinatarios autorizados; resultados de conversión y recompra.
- **Customer:** Responsable de Marketing; Gerente Comercial; dueño o Gerente General; clientes finales que reciben ofertas relevantes.

## 7. Diagrama del proceso AS-IS presentado

![Diagrama del proceso AS-IS de BuyerBrain](assets/buyerbrain/proceso-as-is.png)

Recorrido documentado:

1. El cliente navega o compra en la tienda online.
2. La tienda online registra la actividad.
3. BuyerBrain analiza los datos mediante IA.
4. BuyerBrain prepara una oferta mediante IA.
5. Marketing revisa y aprueba la oferta.
6. BuyerBrain envía la promoción por correo electrónico o WhatsApp.
7. El cliente revisa la promoción.

**Decisión pendiente:** en el gráfico, BuyerBrain realiza el envío, pero en el resumen inferior figura como indefinido si lo hace Marketing. Hay que decidir quién es responsable del envío final y con qué herramienta.

**Nota para revisar:** aunque el equipo lo tituló AS-IS, el flujo incluye BuyerBrain y por eso describe principalmente el proceso futuro propuesto (TO-BE). El AS-IS estricto debería mostrar cómo trabaja hoy la tienda sin BuyerBrain.

## 8. Síntesis actualizada del relevamiento

### Qué encontramos

En marcas medianas de ropa, el equipo plantea como hipótesis que la información del cliente está dispersa entre la tienda online, ventas, catálogo y campañas. Esto obligaría a Marketing a segmentar y diseñar promociones manualmente o mediante reglas generales, provocaría ofertas poco relevantes y dificultaría relacionar cada promoción con una compra.

Actualmente no hay evidencia directa que valide esta hipótesis. No se realizaron entrevistas ni se revisaron observaciones, métricas o campañas anteriores.

La primera validación será pedirle a un Responsable de Marketing Digital que reconstruya su última campaña real: datos consultados, segmentación aplicada, tiempo requerido, oferta enviada y forma de evaluar el resultado.

### Usuario principal

**Quién:** Responsable de Marketing Digital de una marca mediana de ropa.

**Por qué este y no otro:** es quien segmentaría clientes, crearía promociones y analizaría sus resultados. Se define por esta función y no por jerarquía, porque los cargos y responsabilidades varían entre empresas. Debe confirmarse mediante entrevistas.

### Recorrido central

1. El cliente agrega productos al carrito y abandona la compra.
2. La tienda online registra el carrito abandonado y BuyerBrain recibe los datos.
3. BuyerBrain analiza el carrito, el historial y los intereses disponibles.
4. BuyerBrain propone una oferta personalizada.
5. El Responsable de Marketing Digital revisa y aprueba la oferta.
6. BuyerBrain envía la oferta al cliente por WhatsApp.
7. El cliente recibe y revisa la promoción.
8. El cliente completa la compra.
9. BuyerBrain relaciona la compra con la oferta y registra el resultado.

La aprobación manual se incluye al principio para controlar la calidad. Podría eliminarse más adelante si los resultados generan suficiente confianza.

### Segundo disparador pendiente

Además del abandono del carrito, el equipo quiere contemplar la falta de recompra: un cliente anterior supera un período definido sin volver a comprar. Todavía falta diseñar y validar este recorrido.

### Huecos

- No hay entrevistas ni evidencia directa del problema.
- No sabemos cómo Marketing segmenta actualmente ni qué datos utiliza.
- No están confirmados el tiempo invertido, la frecuencia ni el impacto económico.
- No sabemos qué herramientas intervienen ni cómo se transfieren los datos.
- Debe validarse que el Responsable de Marketing Digital sea quien más sufre el problema.
- Deben definirse el momento exacto del abandono y las condiciones de la oferta.
- Deben revisarse el consentimiento del cliente y las reglas para contactarlo por WhatsApp.
- Instagram y email quedan como canales alternativos por evaluar.
- Falta definir cómo atribuir una compra a una oferta.
