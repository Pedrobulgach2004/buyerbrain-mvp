window.CANVAS_DATA = {
  "proyecto": "",
  "equipo": "",
  "bloques": {
    "problema":          { "contenido": "", "estado": "vacio" },
    "segmento":          { "contenido": "", "estado": "vacio" },
    "propuesta_valor":   { "contenido": "", "estado": "vacio" },
    "solucion":          { "contenido": "", "estado": "vacio" },
    "canales":           { "contenido": "", "estado": "vacio" },
    "metricas":          { "contenido": "", "estado": "vacio" },
    "valor_capturado":   { "contenido": "", "estado": "vacio" },
    "estructura_costos": { "contenido": "", "estado": "vacio" },
    "ventaja_injusta":   { "contenido": "", "estado": "vacio" }
  }
};
